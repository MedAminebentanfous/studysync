"""
Bundle the frontend + in-browser API into ONE static HTML file.
Author: Med Amine Ben Tanfous

    python build_site.py              # -> docs/index.html (full document, e.g. for GitHub Pages)
    python build_site.py --fragment   # -> docs/studysync.html (body-only fragment for embedding hosts)

The bundled page runs the same app.js against static/demo-api.js, which
mirrors the Flask REST API inside the browser, so it needs no server.
"""
import os
import re
import sys

BASE = os.path.abspath(os.path.dirname(__file__))
STATIC = os.path.join(BASE, "static")


def read(name: str) -> str:
    with open(os.path.join(STATIC, name), encoding="utf-8") as f:
        return f.read()


def build(fragment: bool = False) -> str:
    html = read("index.html")
    head = re.search(r"<head>(.*?)</head>", html, re.S).group(1)
    body = re.search(r"<body>(.*?)</body>", html, re.S).group(1)
    head = re.sub(r'\s*<link rel="stylesheet" href="/static/styles.css" />', "", head)
    if fragment:  # the host supplies charset + viewport
        head = re.sub(r'\s*<meta charset[^>]*>|\s*<meta name="viewport"[^>]*>', "", head)
    body = re.sub(r'\s*<script src="/static/app.js"></script>', "", body)
    scripts = f"<script>\n{read('demo-api.js')}\n</script>\n<script>\n{read('app.js')}\n</script>"
    style = f"<style>\n{read('styles.css')}\n</style>"
    if fragment:
        return f"{head.strip()}\n{style}\n{body.strip()}\n{scripts}\n"
    return (f'<!DOCTYPE html>\n<html lang="en">\n<head>\n{head.strip()}\n{style}\n</head>\n'
            f"<body>\n{body.strip()}\n{scripts}\n</body>\n</html>\n")


if __name__ == "__main__":
    frag = "--fragment" in sys.argv
    out_dir = os.path.join(BASE, "docs")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "studysync.html" if frag else "index.html")
    with open(out, "w", encoding="utf-8") as f:
        f.write(build(frag))
    print(f"Wrote {out} ({os.path.getsize(out) // 1024} KB)")
