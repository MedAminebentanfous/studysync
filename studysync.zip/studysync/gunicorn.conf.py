"""
Gunicorn settings for StudySync (read automatically by `gunicorn wsgi:app`).
Author: Med Amine Ben Tanfous
"""
import os

# Render gives the port to listen on in $PORT (default 10000).
bind = f"0.0.0.0:{os.environ.get('PORT', '10000')}"

# 2 processes x 4 threads fits easily in Render's 512 MB instances.
workers = int(os.environ.get("WEB_CONCURRENCY", "2"))
worker_class = "gthread"
threads = int(os.environ.get("GUNICORN_THREADS", "4"))

# Load the app once before forking, so the database is created by a single process.
preload_app = True

timeout = 60
graceful_timeout = 30
keepalive = 5

# Trust the X-Forwarded-* headers set by Render's proxy.
forwarded_allow_ips = "*"

accesslog = "-"
errorlog = "-"
loglevel = os.environ.get("LOG_LEVEL", "info").lower()
