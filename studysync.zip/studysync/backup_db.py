"""
Make a consistent copy of the SQLite database (safe while the app is running).
Author: Med Amine Ben Tanfous

    python backup_db.py                     # -> backups/studysync-YYYYmmdd-HHMMSS.db
    python backup_db.py /path/to/copy.db    # custom destination

Uses SQLite's online backup API, so it never copies a half-written file.
On Render, run it from the service's Shell tab and download the file, or rely
on the disk's automatic daily snapshots (kept 7 days).
"""
import os
import sqlite3
import sys
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.environ.get("STUDYSYNC_DB", os.path.join(BASE_DIR, "studysync.db"))


def backup(dest: str | None = None) -> str:
    if not os.path.exists(DB_PATH):
        raise SystemExit(f"No database found at {DB_PATH}")
    if dest is None:
        folder = os.path.join(os.path.dirname(DB_PATH), "backups")
        os.makedirs(folder, exist_ok=True)
        dest = os.path.join(folder, f"studysync-{datetime.now():%Y%m%d-%H%M%S}.db")
    src = sqlite3.connect(DB_PATH)
    out = sqlite3.connect(dest)
    try:
        src.backup(out)
    finally:
        out.close()
        src.close()
    return dest


if __name__ == "__main__":
    print("Backup written to", backup(sys.argv[1] if len(sys.argv) > 1 else None))
