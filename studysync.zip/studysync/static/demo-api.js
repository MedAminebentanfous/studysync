/* =====================================================================
   StudySync — in-browser API (hosted demo build only)
   Author: Med Amine Ben Tanfous

   Mirrors every REST endpoint in app.py so the exact same frontend
   (app.js) runs as a static site. It intercepts fetch('/api/...') calls
   and serves them from a store saved in this browser's localStorage.
   The Flask + SQLite backend is the real server; this file is not used
   when you run `python app.py`.
   ===================================================================== */
(function () {
  'use strict';
  window.STUDYSYNC_DEMO = true;

  const KEY = 'studysync-demo-v1';
  const DEMO_UPLOAD_LIMIT = 2 * 1024 * 1024; // browser storage is small
  const ALLOWED_EXT = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'csv', 'txt', 'md', 'png', 'jpg', 'jpeg',
    'gif', 'webp', 'zip', 'py', 'ipynb', 'odt', 'odp'];
  const GRADE_TYPES = ['exam', 'quiz', 'homework', 'project', 'oral', 'lab', 'other'];
  const PRIORITIES = ['low', 'medium', 'high'];
  const STATUSES = ['todo', 'in_progress', 'done'];
  const realFetch = window.fetch.bind(window);

  // ------------------------------------------------------------- dates
  const pad = (n) => String(n).padStart(2, '0');
  const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const shift = (days) => { const d = new Date(); d.setDate(d.getDate() + days); return d; };
  const dateIn = (days) => isoDate(shift(days));
  const localDT = (days, hm) => `${dateIn(days)}T${hm}`;
  const nowLocal = () => { const d = new Date(); return `${isoDate(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
  const nowStamp = () => new Date().toISOString().slice(0, 19).replace('T', ' ');

  // Demo-only password hashing (cyrb53). The Flask server uses salted scrypt.
  function hash(str) {
    let h1 = 0xdeadbeef; let h2 = 0x41c6ce57;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return `demo$${(4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36)}`;
  }

  // -------------------------------------------------------------- seed
  function seed() {
    const db = {
      seq: { users: 1, subjects: 5, grades: 0, tasks: 0, exams: 0, resources: 0 },
      session: null,
      users: [{ id: 1, full_name: 'Demo Student', email: 'demo@studysync.app', password_hash: hash('studysync:demo1234'), grade_scale: 20, created_at: nowStamp() }],
      subjects: [
        { id: 1, user_id: 1, name: 'Mathematics', coefficient: 4, target_average: 16, color: '#4f46e5' },
        { id: 2, user_id: 1, name: 'Physics', coefficient: 3, target_average: 14, color: '#0891b2' },
        { id: 3, user_id: 1, name: 'Computer Science', coefficient: 3, target_average: 17, color: '#16a34a' },
        { id: 4, user_id: 1, name: 'English', coefficient: 2, target_average: 15, color: '#d97706' },
        { id: 5, user_id: 1, name: 'Philosophy', coefficient: 1, target_average: 12, color: '#db2777' },
      ].map((s) => ({ ...s, created_at: nowStamp() })),
      grades: [], tasks: [], exams: [], resources: [],
    };
    const add = (table, row) => { db.seq[table] += 1; db[table].push({ id: db.seq[table], user_id: 1, created_at: nowStamp(), ...row }); };
    [
      [1, 'Calculus quiz', 'quiz', 15.5, 20, 0.5, -40], [1, 'Midterm exam', 'exam', 14, 20, 2, -25],
      [1, 'Linear algebra homework', 'homework', 18, 20, 1, -10], [2, 'Mechanics lab', 'lab', 16, 20, 1, -35],
      [2, 'Midterm exam', 'exam', 11.5, 20, 2, -24], [3, 'Algorithms project', 'project', 92, 100, 2, -20],
      [3, 'Data structures quiz', 'quiz', 17, 20, 1, -8], [4, 'Essay', 'homework', 14, 20, 1, -30],
      [4, 'Oral presentation', 'oral', 16, 20, 1, -12], [5, 'Dissertation', 'exam', 11, 20, 1, -15],
    ].forEach(([subject_id, title, grade_type, score, max_score, weight, d]) =>
      add('grades', { subject_id, title, grade_type, score, max_score, weight, graded_on: dateIn(d) }));
    [
      [1, 'Revise integration by parts', 'Chapter 4 exercises 1-15', 2, 'high', 'todo'],
      [2, 'Redo midterm mistakes', 'Focus on energy conservation', 4, 'high', 'in_progress'],
      [3, 'Implement Dijkstra in Python', 'Compare heap vs. array versions', 6, 'medium', 'todo'],
      [4, 'Read "Animal Farm" ch. 5-7', '', 9, 'low', 'todo'],
      [5, 'Outline dissertation plan', 'Thesis / antithesis / synthesis', -1, 'medium', 'todo'],
      [1, 'Flashcards: trig identities', '', -3, 'low', 'done'],
    ].forEach(([subject_id, title, description, d, priority, status]) =>
      add('tasks', { subject_id, title, description, due_date: dateIn(d), priority, status, completed_at: status === 'done' ? `${dateIn(d)}T18:00:00` : null }));
    [
      [1, 'Mathematics final', 12, '09:00', 'Amphi A', 'Calculator allowed'],
      [2, 'Physics final', 15, '14:00', 'Room 204', ''],
      [3, 'CS practical exam', 20, '10:30', 'Lab 3', 'Bring student ID'],
    ].forEach(([subject_id, title, d, hm, location, notes]) => add('exams', { subject_id, title, exam_at: localDT(d, hm), location, notes }));
    [
      [1, 'MIT OCW: Single Variable Calculus', 'Course', 'https://ocw.mit.edu/courses/18-01sc-single-variable-calculus-fall-2010/', 'Great lecture videos'],
      [1, '3Blue1Brown: Essence of Linear Algebra', 'Video', 'https://www.3blue1brown.com/topics/linear-algebra', ''],
      [2, 'HyperPhysics', 'Reference', 'http://hyperphysics.phy-astr.gsu.edu/hbase/index.html', 'Concept maps'],
      [3, 'Visualgo: algorithm animations', 'Interactive', 'https://visualgo.net/en', ''],
      [4, 'Purdue OWL: essay writing', 'Article', 'https://owl.purdue.edu/owl/general_writing/index.html', ''],
    ].forEach(([subject_id, title, category, url, notes]) => add('resources', { subject_id, title, category, kind: 'link', url, notes }));
    return db;
  }

  // ----------------------------------------------------------- storage
  function load() { try { const raw = localStorage.getItem(KEY); return raw ? JSON.parse(raw) : null; } catch { return null; } }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(db)); return true; } catch { return false; } }
  let db = load() || seed();
  save();

  window.StudySyncDemo = {
    reset() { const session = db.session; db = seed(); db.session = session && db.users.some((u) => u.id === session) ? session : null; save(); },
  };

  // ------------------------------------------------------------ errors
  class ApiErr extends Error { constructor(msg, status = 400, fields = {}) { super(msg); this.status = status; this.fields = fields; } }

  const reqStr = (d, k, label, max = 200, required = true) => {
    const v = d[k];
    if (v === undefined || v === null || (typeof v === 'string' && !v.trim())) {
      if (required) throw new ApiErr(`${label} is required.`, 400, { [k]: 'required' });
      return null;
    }
    const s = String(v).trim();
    if (s.length > max) throw new ApiErr(`${label} must be at most ${max} characters.`, 400, { [k]: 'too long' });
    return s;
  };
  const reqNum = (d, k, label, { min, max, exclusiveMin = false, required = true } = {}) => {
    const v = d[k];
    if (v === undefined || v === null || v === '') {
      if (required) throw new ApiErr(`${label} is required.`, 400, { [k]: 'required' });
      return null;
    }
    const n = Number(v);
    if (!Number.isFinite(n)) throw new ApiErr(`${label} must be a number.`, 400, { [k]: 'invalid' });
    if (min !== undefined && (exclusiveMin ? n <= min : n < min)) throw new ApiErr(`${label} must be ${exclusiveMin ? 'greater than' : 'at least'} ${min}.`, 400, { [k]: 'out of range' });
    if (max !== undefined && n > max) throw new ApiErr(`${label} must be at most ${max}.`, 400, { [k]: 'out of range' });
    return n;
  };
  const reqChoice = (d, k, label, choices, def) => {
    const v = d[k] ?? def;
    if (!choices.includes(v)) throw new ApiErr(`${label} must be one of: ${[...choices].sort().join(', ')}.`, 400, { [k]: 'invalid' });
    return v;
  };
  const reqDate = (d, k, label) => {
    const v = d[k];
    if (!v) return null;
    const s = String(v).slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s) || Number.isNaN(new Date(`${s}T00:00`).getTime())) throw new ApiErr(`${label} must be a date (YYYY-MM-DD).`, 400, { [k]: 'invalid' });
    return s;
  };
  const reqDateTime = (d, k, label) => {
    const v = d[k];
    if (!v) throw new ApiErr(`${label} is required.`, 400, { [k]: 'required' });
    const m = String(v).match(/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})/);
    if (!m || Number.isNaN(new Date(`${m[1]}T${m[2]}`).getTime())) throw new ApiErr(`${label} must be a date-time (YYYY-MM-DDTHH:MM).`, 400, { [k]: 'invalid' });
    return `${m[1]}T${m[2]}`;
  };

  // ----------------------------------------------------------- helpers
  let uid = null;
  const mine = (table) => db[table].filter((r) => r.user_id === uid);
  const ownOr404 = (table, id) => {
    const row = db[table].find((r) => r.id === Number(id) && r.user_id === uid);
    if (!row) throw new ApiErr(`${table[0].toUpperCase()}${table.slice(1, -1)} not found.`, 404);
    return row;
  };
  const optionalSubject = (d) => {
    const v = d.subject_id;
    if (v === undefined || v === null || v === '' || v === 'null') return null;
    const n = Number(v);
    if (!Number.isInteger(n)) throw new ApiErr('Invalid subject.', 400, { subject_id: 'invalid' });
    ownOr404('subjects', n);
    return n;
  };
  const insert = (table, row) => { db.seq[table] += 1; const r = { id: db.seq[table], user_id: uid, created_at: nowStamp(), ...row }; db[table].push(r); return r; };
  const remove = (table, id) => { db[table] = db[table].filter((r) => r.id !== Number(id)); };
  const subjectOf = (id) => db.subjects.find((s) => s.id === id);
  const withSubject = (row, extra = false) => {
    const s = row.subject_id ? subjectOf(row.subject_id) : null;
    const out = { ...row, subject_name: s ? s.name : null, subject_color: s ? s.color : null };
    if (extra) out.subject_coefficient = s ? s.coefficient : null;
    return out;
  };
  const publicUser = (u) => ({ id: u.id, full_name: u.full_name, email: u.email, grade_scale: u.grade_scale, created_at: u.created_at });
  const byName = (a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase());
  const PRI = { high: 0, medium: 1, low: 2 };
  const r2 = (n) => Math.round(n * 100) / 100;

  function computePerformance() {
    const scale = db.users.find((u) => u.id === uid).grade_scale;
    const subjects = mine('subjects').sort(byName);
    const grades = mine('grades');
    const breakdown = []; let weighted = 0; let coefSum = 0;
    subjects.forEach((s) => {
      const sg = grades.filter((g) => g.subject_id === s.id);
      const W = sg.reduce((a, g) => a + g.weight, 0);
      const avg = sg.length ? sg.reduce((a, g) => a + (g.score / g.max_score) * scale * g.weight, 0) / W : null;
      if (avg !== null) { weighted += avg * s.coefficient; coefSum += s.coefficient; }
      breakdown.push({
        subject_id: s.id, name: s.name, color: s.color, coefficient: s.coefficient, target_average: s.target_average,
        grade_count: sg.length, average: avg === null ? null : r2(avg),
        weighted_points: avg === null ? null : r2(avg * s.coefficient),
        meets_target: avg !== null && s.target_average != null ? avg >= s.target_average : null,
      });
    });
    breakdown.forEach((b) => { b.contribution = b.weighted_points !== null && coefSum ? r2(b.weighted_points / coefSum) : null; });
    const overall = coefSum ? weighted / coefSum : null;
    const pct = overall === null ? null : (overall / scale) * 100;
    const mention = pct === null ? null : pct >= 80 ? 'Excellent' : pct >= 70 ? 'Very good' : pct >= 60 ? 'Good' : pct >= 50 ? 'Pass' : 'Below pass';
    return {
      grade_scale: scale, overall_average: overall === null ? null : r2(overall),
      percentage: pct === null ? null : Math.round(pct * 10) / 10,
      gpa_4: overall === null ? null : r2(Math.min(4, (overall / scale) * 4)), mention,
      total_coefficient: coefSum, graded_subjects: breakdown.filter((b) => b.average !== null).length, subjects: breakdown,
    };
  }

  const taskSort = (a, b) => (a.status === 'done') - (b.status === 'done')
    || (a.due_date === null) - (b.due_date === null)
    || String(a.due_date).localeCompare(String(b.due_date))
    || PRI[a.priority] - PRI[b.priority] || a.id - b.id;

  // ----------------------------------------------------------- payloads
  function subjectPayload(d, cur) {
    const partial = !!cur; cur = cur || {};
    const name = reqStr(d, 'name', 'Subject name', 80, !partial) ?? cur.name;
    const coefIn = reqNum(d, 'coefficient', 'Coefficient', { min: 0, max: 100, exclusiveMin: true, required: !partial });
    const target = 'target_average' in d ? reqNum(d, 'target_average', 'Target average', { min: 0, max: 1000, required: false }) : (cur.target_average ?? null);
    const color = d.color ?? cur.color ?? '#4f46e5';
    if (!/^#[0-9a-fA-F]{6}$/.test(color)) throw new ApiErr('Color must be a hex value like #4f46e5.', 400, { color: 'invalid' });
    if (mine('subjects').some((s) => s.name.toLowerCase() === name.toLowerCase() && s.id !== cur.id)) throw new ApiErr('An item with that name already exists.', 409);
    return { name, coefficient: coefIn ?? cur.coefficient, target_average: target, color };
  }

  function gradePayload(d, cur) {
    const partial = !!cur; cur = cur || {};
    let subject_id = cur.subject_id;
    if (!partial || 'subject_id' in d) {
      subject_id = optionalSubject(d);
      if (subject_id === null) throw new ApiErr('Subject is required.', 400, { subject_id: 'required' });
    }
    const max = reqNum(d, 'max_score', 'Max score', { min: 0, max: 10000, exclusiveMin: true, required: false }) ?? cur.max_score ?? 20;
    const score = reqNum(d, 'score', 'Score', { min: 0, required: !partial }) ?? cur.score;
    if (score > max) throw new ApiErr('Score cannot exceed the max score.', 400, { score: 'out of range' });
    return {
      subject_id, title: reqStr(d, 'title', 'Title', 120, !partial) ?? cur.title,
      grade_type: reqChoice(d, 'grade_type', 'Type', GRADE_TYPES, cur.grade_type ?? 'exam'),
      score, max_score: max,
      weight: reqNum(d, 'weight', 'Weight', { min: 0, max: 100, exclusiveMin: true, required: false }) ?? cur.weight ?? 1,
      graded_on: reqDate(d, 'graded_on', 'Date') ?? cur.graded_on ?? isoDate(new Date()),
    };
  }

  function taskPayload(d, cur) {
    const partial = !!cur; cur = cur || {};
    const status = reqChoice(d, 'status', 'Status', STATUSES, cur.status ?? 'todo');
    return {
      title: reqStr(d, 'title', 'Title', 150, !partial) ?? cur.title,
      description: 'description' in d ? (reqStr(d, 'description', 'Description', 2000, false) ?? '') : (cur.description ?? ''),
      priority: reqChoice(d, 'priority', 'Priority', PRIORITIES, cur.priority ?? 'medium'),
      status,
      due_date: 'due_date' in d ? reqDate(d, 'due_date', 'Due date') : (cur.due_date ?? null),
      subject_id: 'subject_id' in d ? optionalSubject(d) : (cur.subject_id ?? null),
      completed_at: status === 'done' ? (cur.completed_at || new Date().toISOString().slice(0, 19)) : null,
    };
  }

  function examPayload(d, cur) {
    const partial = !!cur; cur = cur || {};
    return {
      title: reqStr(d, 'title', 'Title', 120, !partial) ?? cur.title,
      exam_at: !partial || 'exam_at' in d ? reqDateTime(d, 'exam_at', 'Exam date') : cur.exam_at,
      location: 'location' in d ? (reqStr(d, 'location', 'Location', 120, false) ?? '') : (cur.location ?? ''),
      notes: 'notes' in d ? (reqStr(d, 'notes', 'Notes', 1000, false) ?? '') : (cur.notes ?? ''),
      subject_id: 'subject_id' in d ? optionalSubject(d) : (cur.subject_id ?? null),
    };
  }

  const validUrl = (url) => {
    if (!/^https?:\/\/[^\s/$.?#].[^\s]*$/i.test(url)) throw new ApiErr('URL must start with http:// or https://', 400, { url: 'invalid' });
    return url;
  };
  const readAsDataUrl = (file) => new Promise((res, rej) => {
    const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = () => rej(new ApiErr('Could not read the file.')); fr.readAsDataURL(file);
  });
  const resourceOut = (r) => { const o = withSubject(r); o.file_url = r.data_url || null; delete o.data_url; return o; };

  // ------------------------------------------------------------- routes
  const routes = [];
  const route = (methods, pattern, fn, auth = true) => routes.push({ methods: methods.split(' '), re: new RegExp(`^${pattern}$`), fn, auth });

  route('GET', '/api/health', () => ({ status: 'ok', mode: 'browser-demo' }), false);

  route('POST', '/api/auth/register', ({ body }) => {
    const full_name = reqStr(body, 'full_name', 'Full name', 100);
    const email = reqStr(body, 'email', 'Email', 254).toLowerCase();
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new ApiErr('Please enter a valid email address.', 400, { email: 'invalid' });
    const pw = body.password || '';
    if (pw.length < 8) throw new ApiErr('Password must be at least 8 characters.', 400, { password: 'too short' });
    if (db.users.some((u) => u.email === email)) throw new ApiErr('An account with this email already exists.', 409, { email: 'taken' });
    db.seq.users += 1;
    const u = { id: db.seq.users, full_name, email, password_hash: hash(`studysync:${pw}`), grade_scale: 20, created_at: nowStamp() };
    db.users.push(u);
    db.session = u.id;
    return [{ user: publicUser(u) }, 201];
  }, false);

  route('POST', '/api/auth/login', ({ body }) => {
    const email = String(body.email || '').trim().toLowerCase();
    const u = db.users.find((x) => x.email === email);
    if (!u || u.password_hash !== hash(`studysync:${body.password || ''}`)) throw new ApiErr('Invalid email or password.', 401);
    db.session = u.id;
    return { user: publicUser(u) };
  }, false);

  route('POST', '/api/auth/logout', () => { db.session = null; return { ok: true }; }, false);
  route('GET', '/api/auth/me', () => ({ user: publicUser(db.users.find((u) => u.id === uid)) }));
  route('PUT PATCH', '/api/auth/me', ({ body }) => {
    const u = db.users.find((x) => x.id === uid);
    u.full_name = reqStr(body, 'full_name', 'Full name', 100, false) ?? u.full_name;
    u.grade_scale = reqNum(body, 'grade_scale', 'Grade scale', { min: 0, max: 1000, exclusiveMin: true, required: false }) ?? u.grade_scale;
    return { user: publicUser(u) };
  });

  // subjects
  route('GET', '/api/subjects', () => {
    const perf = Object.fromEntries(computePerformance().subjects.map((b) => [b.subject_id, b]));
    return { subjects: mine('subjects').sort(byName).map((s) => ({ ...s, average: perf[s.id]?.average ?? null, grade_count: perf[s.id]?.grade_count ?? 0 })) };
  });
  route('POST', '/api/subjects', ({ body }) => [{ subject: insert('subjects', subjectPayload(body)) }, 201]);
  route('GET', '/api/subjects/(\\d+)', ({ m }) => {
    const s = ownOr404('subjects', m[1]);
    return { subject: { ...s, grades: mine('grades').filter((g) => g.subject_id === s.id).sort((a, b) => b.graded_on.localeCompare(a.graded_on)) } };
  });
  route('PUT PATCH', '/api/subjects/(\\d+)', ({ m, body }) => {
    const s = ownOr404('subjects', m[1]);
    Object.assign(s, subjectPayload(body, s));
    return { subject: s };
  });
  route('DELETE', '/api/subjects/(\\d+)', ({ m }) => {
    const s = ownOr404('subjects', m[1]);
    db.grades = db.grades.filter((g) => g.subject_id !== s.id); // ON DELETE CASCADE
    ['tasks', 'exams', 'resources'].forEach((t) => db[t].forEach((r) => { if (r.subject_id === s.id) r.subject_id = null; })); // SET NULL
    remove('subjects', s.id);
    return { ok: true };
  });

  // grades
  const gradeList = () => mine('grades').map((g) => withSubject(g, true))
    .sort((a, b) => b.graded_on.localeCompare(a.graded_on) || b.id - a.id);
  route('GET', '/api/grades', ({ q }) => {
    const sid = q.get('subject_id');
    return { grades: gradeList().filter((g) => !sid || g.subject_id === Number(sid)) };
  });
  route('POST', '/api/grades', ({ body }) => [{ grade: withSubject(insert('grades', gradePayload(body)), true) }, 201]);
  route('GET', '/api/grades/(\\d+)', ({ m }) => ({ grade: withSubject(ownOr404('grades', m[1]), true) }));
  route('PUT PATCH', '/api/grades/(\\d+)', ({ m, body }) => {
    const g = ownOr404('grades', m[1]);
    Object.assign(g, gradePayload(body, g));
    return { grade: withSubject(g, true) };
  });
  route('DELETE', '/api/grades/(\\d+)', ({ m }) => { remove('grades', ownOr404('grades', m[1]).id); return { ok: true }; });
  route('GET', '/api/performance', () => computePerformance());

  // tasks
  route('GET', '/api/tasks', ({ q }) => {
    const status = q.get('status'); const priority = q.get('priority'); const sid = q.get('subject_id');
    if (status && !STATUSES.includes(status)) throw new ApiErr('Invalid status filter.');
    if (priority && !PRIORITIES.includes(priority)) throw new ApiErr('Invalid priority filter.');
    return {
      tasks: mine('tasks').filter((t) => (!status || t.status === status) && (!priority || t.priority === priority)
        && (!sid || t.subject_id === Number(sid))).sort(taskSort).map((t) => withSubject(t)),
    };
  });
  route('POST', '/api/tasks', ({ body }) => [{ task: withSubject(insert('tasks', taskPayload(body))) }, 201]);
  route('GET', '/api/tasks/(\\d+)', ({ m }) => ({ task: withSubject(ownOr404('tasks', m[1])) }));
  route('PUT PATCH', '/api/tasks/(\\d+)', ({ m, body }) => {
    const t = ownOr404('tasks', m[1]);
    Object.assign(t, taskPayload(body, t));
    return { task: withSubject(t) };
  });
  route('POST', '/api/tasks/(\\d+)/toggle', ({ m }) => {
    const t = ownOr404('tasks', m[1]);
    t.status = t.status === 'done' ? 'todo' : 'done';
    t.completed_at = t.status === 'done' ? new Date().toISOString().slice(0, 19) : null;
    return { task: withSubject(t) };
  });
  route('DELETE', '/api/tasks/(\\d+)', ({ m }) => { remove('tasks', ownOr404('tasks', m[1]).id); return { ok: true }; });

  // exams
  route('GET', '/api/exams', ({ q }) => {
    const now = nowLocal();
    return {
      exams: mine('exams').filter((e) => q.get('upcoming') !== '1' || e.exam_at >= now)
        .sort((a, b) => a.exam_at.localeCompare(b.exam_at)).map((e) => withSubject(e)),
    };
  });
  route('POST', '/api/exams', ({ body }) => [{ exam: withSubject(insert('exams', examPayload(body))) }, 201]);
  route('PUT PATCH', '/api/exams/(\\d+)', ({ m, body }) => {
    const e = ownOr404('exams', m[1]);
    Object.assign(e, examPayload(body, e));
    return { exam: withSubject(e) };
  });
  route('DELETE', '/api/exams/(\\d+)', ({ m }) => { remove('exams', ownOr404('exams', m[1]).id); return { ok: true }; });

  // resources
  route('GET', '/api/resources', ({ q }) => {
    const cat = q.get('category'); const sid = q.get('subject_id'); const term = (q.get('q') || '').toLowerCase();
    const list = mine('resources').filter((r) => (!cat || r.category === cat) && (!sid || r.subject_id === Number(sid))
      && (!term || r.title.toLowerCase().includes(term) || (r.notes || '').toLowerCase().includes(term)))
      .sort((a, b) => b.created_at.localeCompare(a.created_at) || b.id - a.id);
    return { resources: list.map(resourceOut), categories: [...new Set(mine('resources').map((r) => r.category))].sort() };
  });
  route('POST', '/api/resources', async ({ body }) => {
    const base = {
      title: reqStr(body, 'title', 'Title', 150),
      category: reqStr(body, 'category', 'Category', 50, false) || 'Other',
      notes: reqStr(body, 'notes', 'Notes', 1000, false) || '',
      subject_id: optionalSubject(body),
    };
    const file = body.file;
    if (file && typeof file === 'object' && file.name) {
      const ext = (file.name.split('.').pop() || '').toLowerCase();
      if (!file.name.includes('.') || !ALLOWED_EXT.includes(ext)) throw new ApiErr('File type not allowed.', 400, { file: 'invalid type' });
      if (file.size > DEMO_UPLOAD_LIMIT) throw new ApiErr('The hosted demo stores files in your browser, so uploads are limited to 2 MB. The Flask version accepts up to 16 MB.', 413);
      const original = file.name.replace(/[^\w.-]+/g, '_');
      const r = insert('resources', { ...base, kind: 'file', stored_name: original, original_name: original, file_size: file.size, data_url: await readAsDataUrl(file) });
      if (!save()) { remove('resources', r.id); throw new ApiErr('Your browser storage is full. Delete an uploaded file and try again.', 413); }
      return [{ resource: resourceOut(r) }, 201];
    }
    const url = validUrl(reqStr(body, 'url', 'URL', 2000));
    return [{ resource: resourceOut(insert('resources', { ...base, kind: 'link', url })) }, 201];
  });
  route('PUT PATCH', '/api/resources/(\\d+)', ({ m, body }) => {
    const r = ownOr404('resources', m[1]);
    r.title = reqStr(body, 'title', 'Title', 150, false) ?? r.title;
    r.category = reqStr(body, 'category', 'Category', 50, false) ?? r.category;
    if ('notes' in body) r.notes = reqStr(body, 'notes', 'Notes', 1000, false) ?? '';
    if ('subject_id' in body) r.subject_id = optionalSubject(body);
    if (r.kind === 'link' && body.url) r.url = validUrl(reqStr(body, 'url', 'URL', 2000));
    return { resource: resourceOut(r) };
  });
  route('DELETE', '/api/resources/(\\d+)', ({ m }) => { remove('resources', ownOr404('resources', m[1]).id); return { ok: true }; });
  route('GET', '/api/resources/(\\d+)/file', async ({ m }) => {
    const r = ownOr404('resources', m[1]);
    if (r.kind !== 'file') throw new ApiErr('This resource is a link, not a file.');
    return { __raw: await (await realFetch(r.data_url)).blob() };
  });

  // dashboard
  route('GET', '/api/dashboard', () => {
    const today = isoDate(new Date());
    const tasks = mine('tasks');
    const open = tasks.filter((t) => t.status !== 'done');
    const now = nowLocal();
    return {
      performance: computePerformance(),
      tasks: {
        total: tasks.length, done: tasks.length - open.length,
        overdue: open.filter((t) => t.due_date && t.due_date < today).length,
        due_today: open.filter((t) => t.due_date === today).length,
      },
      upcoming_tasks: open.sort(taskSort).slice(0, 5).map((t) => withSubject(t)),
      next_exams: mine('exams').filter((e) => e.exam_at >= now).sort((a, b) => a.exam_at.localeCompare(b.exam_at)).slice(0, 3).map((e) => withSubject(e)),
      recent_grades: gradeList().slice(0, 5),
      resource_count: mine('resources').length,
    };
  });

  // ------------------------------------------------------ fetch shim
  const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'Content-Type': 'application/json' } });

  window.fetch = async function (input, init = {}) {
    const url = new URL(typeof input === 'string' ? input : input.url, location.href);
    const idx = url.pathname.indexOf('/api/');
    if (idx === -1) return realFetch(input, init);
    const path = url.pathname.slice(idx);
    const method = (init.method || 'GET').toUpperCase();

    let body = {};
    if (init.body instanceof FormData) init.body.forEach((v, k) => { body[k] = v; });
    else if (typeof init.body === 'string') {
      try { body = JSON.parse(init.body); } catch { return json({ error: 'Request body must be valid JSON.' }, 400); }
      if (!body || typeof body !== 'object' || Array.isArray(body)) return json({ error: 'Request body must be a JSON object.' }, 400);
    }

    let pathMatched = false;
    for (const r of routes) {
      const m = path.match(r.re);
      if (!m) continue;
      pathMatched = true;
      if (!r.methods.includes(method)) continue;
      try {
        uid = db.session;
        if (r.auth && (uid === null || !db.users.some((u) => u.id === uid))) {
          db.session = null; save();
          throw new ApiErr('Authentication required.', 401);
        }
        let out = await r.fn({ m, body, q: url.searchParams });
        save();
        if (out && out.__raw) return new Response(out.__raw, { status: 200 });
        let status = 200;
        if (Array.isArray(out)) [out, status] = out;
        await new Promise((res) => setTimeout(res, 60)); // feel like a network round-trip
        return json(out, status);
      } catch (err) {
        if (err instanceof ApiErr) return json({ error: err.message, fields: err.fields }, err.status);
        console.error(err);
        return json({ error: 'Something went wrong. Please try again.' }, 500);
      }
    }
    return pathMatched ? json({ error: 'Method not allowed.' }, 405) : json({ error: 'Endpoint not found.' }, 404);
  };
}());
