# Déployer StudySync sur Render

Auteur : Med Amine Ben Tanfous

Ce guide met StudySync en ligne avec son vrai backend Flask, à une adresse du type `https://studysync.onrender.com`. Le code tourne sur Render, à partir de votre dépôt GitHub.

---

## 1. Choisir une option pour les données

Sur Render, le disque d'un service est **temporaire**. Tout fichier écrit en dehors d'un disque persistant, y compris la base SQLite et les fichiers envoyés, est effacé à chaque redéploiement, redémarrage ou mise en veille. Il y a deux façons de déployer :

| | Option A : Starter + disque persistant | Option B : gratuite |
|---|---|---|
| Prix | Payant (instance Starter + disque de 1 Go, voir render.com/pricing) | 0 € |
| Les comptes, notes, tâches et fichiers sont conservés | **Oui** | **Non**, tout repart de zéro à chaque redémarrage |
| Mise en veille | Non, le site répond tout de suite | Après 15 min sans visite ; environ 1 min pour se réveiller |
| Sauvegardes | Instantanés automatiques quotidiens (gardés 7 jours) + `backup_db.py` | Aucune |
| Usage conseillé | Une vraie application utilisée au quotidien | Une démo pour le CV, avec le compte démo recréé à chaque démarrage |

Le fichier `render.yaml` correspond à l'**option A**. Pour l'option B, suivez la section 4.

---

## 2. Mettre le projet sur GitHub

Vous avez déjà le dépôt `MedAminebentanfous/studysync`. Il faut remplacer son contenu par la nouvelle version.

1. Décompressez `studysync.zip` sur votre ordinateur.
2. Sur GitHub, ouvrez le dépôt, puis **Add file → Upload files**.
3. Ouvrez le dossier `studysync` décompressé et glissez **son contenu** (pas le dossier lui-même) dans la page :
   `app.py`, `wsgi.py`, `gunicorn.conf.py`, `render.yaml`, `requirements.txt`, `requirements-dev.txt`, `schema.sql`, `init_db.py`, `backup_db.py`, `build_site.py`, `README.md`, `DEPLOIEMENT.md`, `LICENSE`, et les dossiers `static`, `tests`, `docs`, `uploads`.
4. Ajoutez aussi les fichiers qui commencent par un point : `.python-version`, `.gitignore`, `.env.example`.
   - Sous Windows, ils s'affichent normalement.
   - Sous macOS, appuyez sur **Cmd + Maj + .** dans le Finder pour les voir.
5. Cliquez sur **Commit changes**.

**Vérification** : sur l'onglet **Code** du dépôt, `app.py` et `render.yaml` doivent être **à la racine**, pas dans un sous-dossier `studysync/`. S'ils sont dans un sous-dossier, indiquez `studysync` dans le champ **Root Directory** de Render (étape 3 ou 4).

---

## 3. Option A : déploiement avec données conservées (Blueprint)

1. Allez sur **render.com** et cliquez sur **Get Started**. Inscrivez-vous avec **GitHub** et autorisez Render à accéder au dépôt `studysync`.
2. Dans le tableau de bord, cliquez sur **New +**, puis **Blueprint**.
3. Choisissez le dépôt **studysync**. Render lit `render.yaml` et affiche :
   - un service web **studysync** (Python, instance Starter, région Frankfurt) ;
   - un disque **studysync-data** de 1 Go monté sur `/var/data`.
4. Donnez un nom au Blueprint (par exemple `studysync`), puis cliquez sur **Apply**. Render demande une carte bancaire, puisque l'instance Starter et le disque sont payants.
5. Ouvrez le service **studysync** et regardez l'onglet **Logs**. Le premier déploiement prend 2 à 4 minutes. Il est terminé quand vous voyez :
   ```
   StudySync database created at /var/data/studysync.db with demo data
   Starting gunicorn 23.0.0
   ==> Your service is live 🎉
   ```
6. Votre adresse s'affiche en haut de la page du service, par exemple `https://studysync.onrender.com`. Si ce nom est déjà pris, Render ajoute un suffixe, par exemple `studysync-x1y2.onrender.com`.
7. Ouvrez l'adresse et connectez-vous avec `demo@studysync.app` / `demo1234`, ou créez votre propre compte.

**Tester que les données restent** : ajoutez une tâche, puis cliquez sur **Manual Deploy → Deploy latest commit**. Une fois le déploiement terminé, rechargez le site : la tâche est toujours là.

Variables configurées automatiquement par `render.yaml` :

| Variable | Valeur | Rôle |
|---|---|---|
| `STUDYSYNC_SECRET_KEY` | générée par Render | Signe les cookies de connexion |
| `STUDYSYNC_DB` | `/var/data/studysync.db` | Base SQLite, sur le disque persistant |
| `STUDYSYNC_UPLOADS` | `/var/data/uploads` | Fichiers envoyés, sur le disque persistant |
| `STUDYSYNC_SEED_DEMO` | `1` | Crée le compte démo à la toute première création de la base |
| `STUDYSYNC_SECURE_COOKIES` | `1` | Cookies réservés au HTTPS |
| `TZ` | `Africa/Tunis` | Fuseau horaire pour « aujourd'hui » et les examens à venir |

---

## 4. Option B : déploiement gratuit (sans conservation des données)

N'utilisez **pas** Blueprint ici, car `render.yaml` demande une instance payante et un disque.

1. Sur render.com, cliquez sur **New +**, puis **Web Service**, et choisissez le dépôt **studysync**.
2. Remplissez le formulaire :
   - **Name** : `studysync`
   - **Region** : `Frankfurt (EU Central)`
   - **Branch** : `main`
   - **Root Directory** : laissez vide (sauf si les fichiers sont dans un sous-dossier, voir l'étape 2)
   - **Runtime / Language** : `Python 3`
   - **Build Command** : `pip install -r requirements.txt`
   - **Start Command** : `gunicorn wsgi:app`
   - **Instance Type** : `Free`
3. Dans **Environment Variables**, ajoutez :
   - `STUDYSYNC_SECRET_KEY` : cliquez sur **Generate** pour créer une valeur aléatoire
   - `STUDYSYNC_SEED_DEMO` = `1`
   - `STUDYSYNC_SECURE_COOKIES` = `1`
   - `TZ` = `Africa/Tunis`

   Ne définissez **pas** `STUDYSYNC_DB` : il n'y a pas de disque, la base reste dans le dossier du projet.
4. Ouvrez **Advanced** et indiquez `/api/health` dans **Health Check Path**.
5. Cliquez sur **Create Web Service** et attendez **Your service is live** dans les logs.
6. L'adresse s'affiche en haut de la page, par exemple `https://studysync.onrender.com`.

À savoir : après 15 minutes sans visite, le service se met en veille. La visite suivante le réveille en une minute environ, avec une base neuve qui contient le compte démo. Pour passer plus tard à l'option A, changez l'instance pour **Starter** dans **Settings**, ajoutez un disque monté sur `/var/data` (onglet **Disks**), puis ajoutez `STUDYSYNC_DB=/var/data/studysync.db` et `STUDYSYNC_UPLOADS=/var/data/uploads`.

---

## 5. Mettre le site à jour

Chaque modification envoyée sur la branche `main` de GitHub (fichier modifié puis **Commit changes**) redéploie le site automatiquement. Avec l'option A, les données sont conservées à chaque mise à jour.

## 6. Sauvegarder la base (option A)

- Render prend un **instantané quotidien** du disque, gardé 7 jours. Il se restaure depuis l'onglet **Disks** du service.
- Pour une copie à la demande, ouvrez l'onglet **Shell** du service et lancez :
  ```
  python backup_db.py
  ```
  La copie est écrite dans `/var/data/backups/`.
- Ne lancez **jamais** `python init_db.py` sur Render : ce script efface la base. Il refuse d'ailleurs de s'exécuter sur Render sans l'option `--force`.

## 7. Nom de domaine personnalisé (facultatif)

Si vous achetez un domaine, par exemple `studysync.tn` ou `medamine.dev`, ouvrez **Settings → Custom Domains**, cliquez sur **Add Custom Domain** et suivez les instructions DNS affichées. Render fournit le certificat HTTPS gratuitement.

## 8. Problèmes fréquents

| Symptôme | Cause probable et solution |
|---|---|
| `Could not open requirements file` pendant le build | Les fichiers sont dans un sous-dossier : indiquez-le dans **Root Directory**. |
| `gunicorn: command not found` | `requirements.txt` n'a pas été envoyé ou ne contient pas `gunicorn==23.0.0`. |
| `ModuleNotFoundError: No module named 'app'` | La commande de démarrage doit être exactement `gunicorn wsgi:app`, avec `app.py` et `wsgi.py` à la racine. |
| La connexion ne tient pas (retour à l'écran de connexion) | Ouvrez le site en `https://`. `STUDYSYNC_SECURE_COOKIES=1` exige le HTTPS, que Render fournit toujours. |
| Les données disparaissent après un déploiement | Pas de disque persistant (option B), ou `STUDYSYNC_DB` ne pointe pas vers `/var/data/...`. |
| Le site met une minute à s'ouvrir | Normal avec l'offre gratuite : le service se réveille après sa mise en veille. |

## 9. Et la version GitHub Pages ?

Le dossier `docs/` contient une copie de démonstration qui fonctionne sans serveur et garde les données dans le navigateur de chaque visiteur. Render ne l'utilise pas. Vous pouvez garder les deux liens, ou désactiver GitHub Pages dans **Settings → Pages** pour n'avoir que la version Render.
