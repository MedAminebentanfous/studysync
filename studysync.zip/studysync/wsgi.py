"""
WSGI entry point for production servers.
Author: Med Amine Ben Tanfous

    gunicorn wsgi:app        # Render start command (settings in gunicorn.conf.py)
"""
from app import app

if __name__ == "__main__":
    app.run()
