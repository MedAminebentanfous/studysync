# StudySync — Academic Performance Tracker

**Author:** Med Amine Ben Tanfous

A full-stack web app for students: weighted averages and GPA, a revision planner, live exam countdowns and a study-resource library.

**Live app:** `https://<your-service>.onrender.com` (deployed on Render with Gunicorn; see [DEPLOIEMENT.md](DEPLOIEMENT.md))
Demo login: `demo@studysync.app` / `demo1234`

**Stack:** Python 3.13 · Flask 3.1 · SQLite · Gunicorn · vanilla HTML/CSS/JS (no build step, no frameworks) · pytest

## Features

| Module | What it does |
|---|---|
| **Weighted GPA calculator** | Subjects carry a *coefficient* (credit weight); each grade carries a *weight multiplier* (e.g. final ×2, quiz ×0.5). Scores on any scale (e.g. 92/100) are normalised to your grading scale (/20 by default, or /100, /10, /4). Shows per-subject averages, contribution to the final average, targets, GPA on a 4.0 scale and a standing label. |
| **What-if calculator** | Type a hypothetical grade and see the subject and overall averages update live, plus the minimum score needed to reach your subject target. |
| **Revision planner** | Create, edit, delete and check off tasks with due dates, priority tags (high/medium/low) and status (to do / in progress / done). Filter by status, priority and subject; overdue and due-soon tasks are highlighted. |
| **Exam countdowns** | Add exam dates and watch live day/hour/minute/second timers; urgency badges for exams this week. |
| **Resource manager** | Save links or upload files (≤16 MB), categorise them, attach them to a subject, search and filter. |
| **Accounts** | Register/login with hashed passwords (Werkzeug scrypt) and session cookies; every query is scoped to the logged-in user. |
| **UI** | Responsive (desktop sidebar → mobile drawer), light/dark theme, toasts, modal forms with validation. |

## Formulas

```
normalised grade   = score / max_score × scale
subject average    = Σ(normalised × weight) / Σ weight
overall average    = Σ(subject average × coefficient) / Σ coefficient   (graded subjects only)
GPA (4.0)          = overall / scale × 4
```

## Project structure

```
studysync/
├── app.py               # Flask app: REST API, auto-creates the database, serves the frontend
├── wsgi.py              # Production entry point:  gunicorn wsgi:app
├── gunicorn.conf.py     # Gunicorn settings (port from $PORT, workers, threads, logging)
├── render.yaml          # Render Blueprint (web service + persistent disk)
├── .python-version      # Python version used by Render (3.13)
├── requirements.txt     # Runtime dependencies (Flask, Werkzeug, Gunicorn)
├── requirements-dev.txt # + pytest
├── schema.sql           # Tables, constraints, indexes + sample data
├── init_db.py           # Resets a local database (refuses to run on Render without --force)
├── backup_db.py         # Safe online backup of the SQLite database
├── .env.example         # Environment variables to set on the host
├── static/
│   ├── index.html       # App shell, auth screen, modals
│   ├── styles.css       # Design system, light/dark themes, responsive layout
│   ├── app.js           # SPA: router, fetch API client, all views
│   └── demo-api.js      # Browser-only copy of the API, used ONLY by the optional static build
├── tests/test_api.py    # 15 pytest tests (API, maths, isolation, bootstrap, persistence, demo reset)
├── uploads/             # Uploaded files in local development
├── build_site.py        # Optional: bundles a server-less demo into docs/index.html
└── docs/index.html      # Optional static demo for GitHub Pages (not used by Render)
```

## Setup & run

```bash
# 1. Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements-dev.txt

# 3. Create the database (schema + sample data)
python init_db.py                  # or: python init_db.py --empty  (no sample data)

# 4. Start the server
python app.py
```

Open **http://127.0.0.1:5000** and sign in with the demo account (pre-filled):
**`demo@studysync.app` / `demo1234`** — or create your own account.

> `init_db.py` drops and recreates all tables, so re-run it any time you want a fresh local demo. You can also skip it: on first start the app creates the tables by itself (and the demo account when `STUDYSYNC_SEED_DEMO=1`). An existing database is never overwritten.

### Run the tests

```bash
python -m pytest -q
```

### Configuration (environment variables)

| Variable | Default | Purpose |
|---|---|---|
| `STUDYSYNC_SECRET_KEY` | dev value | **Set a long random value in production** (signs session cookies). Render generates it from `render.yaml`. |
| `STUDYSYNC_DB` | `./studysync.db` | SQLite database path. On Render: `/var/data/studysync.db` (on the persistent disk) |
| `STUDYSYNC_UPLOADS` | `./uploads` | Uploaded files folder. On Render: `/var/data/uploads` |
| `STUDYSYNC_SEED_DEMO` | off | `1` = create the demo account and sample data when the database is first created |
| `STUDYSYNC_SECURE_COOKIES` | off | `1` when served over HTTPS (Render) |
| `STUDYSYNC_BEHIND_PROXY` | on when `RENDER` is set | Trust `X-Forwarded-*` headers from the host's proxy |
| `TZ` | server default | Time zone used for "today" and upcoming exams, e.g. `Africa/Tunis` |
| `PORT` | `5000` (dev) / `10000` (Gunicorn) | Port to listen on; Render sets it |
| `WEB_CONCURRENCY` / `GUNICORN_THREADS` | `2` / `4` | Gunicorn processes and threads |
| `HOST` | `127.0.0.1` | Bind address for `python app.py` |
| `FLASK_DEBUG` | off | `1` for auto-reload during development |

### Production (Gunicorn)

```bash
export STUDYSYNC_SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export STUDYSYNC_SEED_DEMO=1
gunicorn wsgi:app                  # reads gunicorn.conf.py, listens on $PORT (default 10000)
```
Gunicorn runs on Linux and macOS. On Windows, test with `python app.py`, or `pip install waitress` then `waitress-serve --port=8000 wsgi:app`.

## Deploy on Render

Step-by-step guide (in French): **[DEPLOIEMENT.md](DEPLOIEMENT.md)**. In short: push to GitHub, then in Render choose **New → Blueprint** and select the repository. `render.yaml` sets up the build, the Gunicorn start command, the health check, the environment variables and a 1 GB persistent disk for the SQLite database and uploads.

### Keeping data between deploys

Render's filesystem is temporary: anything written outside a persistent disk is lost on every redeploy, restart or (on the free plan) spin-down. StudySync therefore stores the database and uploads in `/var/data`, the disk declared in `render.yaml`.

| Option | Cost | Data kept? |
|---|---|---|
| **A. Starter + persistent disk** (`render.yaml`) | Starter instance + 1 GB disk | Yes. Render also takes daily disk snapshots, kept 7 days. `python backup_db.py` makes extra copies. |
| **B. Free web service, no disk** | Free | No. The app recreates the demo account on every start, so it works as a resettable demo. |

## Optional: static demo build (GitHub Pages)

```bash
python build_site.py        # writes docs/index.html
```

This is a separate, server-less copy for GitHub Pages only. The Render deployment does not use it and runs the real Flask backend. `docs/index.html` contains the frontend plus `static/demo-api.js`, which intercepts `fetch('/api/...')` and serves every endpoint from browser storage using the same validation and averaging logic as `app.py`. To host it free: push the repo to GitHub, then Settings → Pages → Source: *Deploy from a branch* → Branch `main`, folder `/docs` → Save. The site goes live at `https://<your-username>.github.io/<repo-name>/` within a minute or two. In the demo, uploads are capped at 2 MB and files preview in the page instead of downloading. Run the Flask server for the full experience.

## REST API

All endpoints are JSON, under `/api`, and require a session (except register/login/health). `PUT` and `PATCH` both accept partial updates.

| Method | Endpoint | Description |
|---|---|---|
| POST | `/auth/register` · `/auth/login` · `/auth/logout` | Account & session |
| GET / PATCH | `/auth/me` | Current user; update name / grading scale |
| GET / POST | `/subjects` | List (with averages) / create |
| GET / PUT / PATCH / DELETE | `/subjects/<id>` | Read (with grades) / update / delete (cascades grades) |
| GET / POST | `/grades?subject_id=` | List / create |
| GET / PUT / PATCH / DELETE | `/grades/<id>` | Read / update / delete |
| GET | `/performance` | Weighted averages, GPA, per-subject breakdown |
| GET / POST | `/tasks?status=&priority=&subject_id=` | List (filtered) / create |
| GET / PUT / PATCH / DELETE | `/tasks/<id>` | Read / update / delete |
| POST | `/tasks/<id>/toggle` | Toggle done ↔ to do |
| GET / POST | `/exams?upcoming=1` | List / create |
| PUT / PATCH / DELETE | `/exams/<id>` | Update / delete |
| GET / POST | `/resources?category=&subject_id=&q=` | List + categories / create (JSON link or multipart file) |
| PUT / PATCH / DELETE | `/resources/<id>` | Update / delete (removes stored file) |
| GET | `/resources/<id>/file?download=1` | View / download an uploaded file |
| GET | `/dashboard` | Aggregated summary for the dashboard |
| GET | `/meta` | Whether the public demo account is enabled (no login needed) |
| POST | `/demo/reset` | Restore the demo account's sample data; other accounts are untouched (only when `STUDYSYNC_SEED_DEMO=1`) |

Example:

```bash
curl -c jar -H 'Content-Type: application/json' \
     -d '{"email":"demo@studysync.app","password":"demo1234"}' http://127.0.0.1:5000/api/auth/login
curl -b jar -H 'Content-Type: application/json' \
     -d '{"subject_id":1,"title":"Final","score":17,"max_score":20,"weight":2}' http://127.0.0.1:5000/api/grades
curl -b jar http://127.0.0.1:5000/api/performance
```

## Database schema

`users` 1─* `subjects` 1─* `grades`; `users` 1─* `tasks`, `exams`, `resources` (each optionally linked to a subject, `ON DELETE SET NULL`). CHECK constraints enforce valid priorities, statuses, positive coefficients/weights and `score ≤ max_score`; foreign keys cascade on user/subject deletion. See `schema.sql`.

## Security notes

Salted password hashes · HttpOnly + SameSite session cookies · parameterised SQL everywhere · per-user ownership checks on every row · server-side validation of all input · upload extension allow-list, `secure_filename`, random stored names and a 16 MB limit · output escaping in the frontend to prevent XSS · `http(s)`-only resource URLs.

## Author

**Med Amine Ben Tanfous**. Designed and built StudySync as a full-stack portfolio project.
